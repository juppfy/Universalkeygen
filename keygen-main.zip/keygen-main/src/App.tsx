import { useState } from 'react';
import HeroSection from './components/HeroSection';
import KeyTypeSelector, { KeyType } from './components/KeyTypeSelector';
import ConfigurationPanel from './components/ConfigurationPanel';
import OutputDisplay from './components/OutputDisplay';
import FeaturesGrid from './components/FeaturesGrid';
import { generateKey } from './utils/keyGenerator';
import { Sparkles } from 'lucide-react';

function App() {
  const [selectedType, setSelectedType] = useState<KeyType>('secret');
  const [config, setConfig] = useState<Record<string, any>>({});
  const [output, setOutput] = useState('');

  const handleGenerate = () => {
    const key = generateKey(selectedType, config);
    setOutput(key);
  };

  const handleTypeChange = (type: KeyType) => {
    setSelectedType(type);
    setConfig({});
    setOutput('');
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <HeroSection />

      <main className="max-w-7xl mx-auto px-6 py-16">
        <div className="space-y-8">
          <div>
            <h2 className="text-2xl font-bold text-white mb-6">Select Key Type</h2>
            <KeyTypeSelector selectedType={selectedType} onSelect={handleTypeChange} />
          </div>

          <div>
            <h2 className="text-2xl font-bold text-white mb-6">Configuration</h2>
            <ConfigurationPanel
              keyType={selectedType}
              config={config}
              onConfigChange={setConfig}
            />
          </div>

          <div className="flex justify-center">
            <button
              onClick={handleGenerate}
              className="flex items-center gap-3 bg-green-500 hover:bg-green-600 text-black font-semibold px-8 py-4 transition-colors text-lg"
            >
              <Sparkles className="w-5 h-5" />
              Generate Key
            </button>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-white mb-6">Output</h2>
            <OutputDisplay output={output} keyType={selectedType} />
          </div>
        </div>
      </main>

      <FeaturesGrid />

      <footer className="border-t border-zinc-800 bg-black">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="text-center text-zinc-600 text-sm">
            <p className="mb-2">All keys are generated client-side using the Web Crypto API</p>
            <p>No data is transmitted to any server. Your keys never leave your browser.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
