import type { KeyType } from '../components/KeyTypeSelector';

export function generateKey(keyType: KeyType, config: Record<string, any>): string {
  switch (keyType) {
    case 'secret':
      return generateSecretKey(config);
    case 'base64':
      return generateBase64Key(config);
    case 'ssl':
      return generateSSLKey(config);
    case 'api':
      return generateAPIKey(config);
    case 'jwt':
      return generateJWTSecret(config);
    case 'encryption':
      return generateEncryptionKey(config);
    case 'ssh':
      return generateSSHKey(config);
    default:
      return '';
  }
}

function generateSecretKey(config: Record<string, any>): string {
  const length = config.length || 32;
  const format = config.format || 'hex';

  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);

  switch (format) {
    case 'hex':
      return Array.from(bytes)
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
    case 'base64':
      return btoa(String.fromCharCode(...bytes));
    case 'alphanumeric':
      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      return Array.from(bytes)
        .map(b => chars[b % chars.length])
        .join('');
    default:
      return '';
  }
}

function generateBase64Key(config: Record<string, any>): string {
  const byteLength = config.byteLength || 32;
  const urlSafe = config.urlSafe || false;

  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);

  let base64 = btoa(String.fromCharCode(...bytes));

  if (urlSafe) {
    base64 = base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
  }

  return base64;
}

function generateSSLKey(config: Record<string, any>): string {
  const algorithm = config.algorithm || 'rsa';

  return `-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC${generateRandomBase64(180)}
${generateRandomBase64(200)}
${generateRandomBase64(200)}
${generateRandomBase64(200)}
${algorithm === 'ed25519' ? '' : generateRandomBase64(200)}
-----END PRIVATE KEY-----

-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA${generateRandomBase64(180)}
${generateRandomBase64(100)}
-----END PUBLIC KEY-----

Fingerprint: ${generateFingerprint()}`;
}

function generateAPIKey(config: Record<string, any>): string {
  const format = config.format || 'uuid';

  switch (format) {
    case 'uuid':
      return generateUUID();
    case 'nanoid':
      return generateNanoid(config.length || 21);
    case 'prefixed':
      const prefix = config.prefix || 'sk_live_';
      return prefix + generateNanoid(32);
    default:
      return '';
  }
}

function generateJWTSecret(config: Record<string, any>): string {
  const algorithm = config.algorithm || 'HS256';

  if (algorithm.startsWith('HS')) {
    const length = algorithm === 'HS256' ? 32 : algorithm === 'HS384' ? 48 : 64;
    return generateSecretKey({ length, format: 'base64' });
  } else {
    return generateSSLKey({ algorithm: 'rsa', keySize: '2048' });
  }
}

function generateEncryptionKey(config: Record<string, any>): string {
  const algorithm = config.algorithm || 'aes-256';
  const format = config.format || 'hex';

  const lengths: Record<string, number> = {
    'aes-128': 16,
    'aes-192': 24,
    'aes-256': 32,
    'chacha20': 32,
  };

  const length = lengths[algorithm] || 32;
  return generateSecretKey({ length, format });
}

function generateSSHKey(config: Record<string, any>): string {
  const algorithm = config.algorithm || 'ed25519';

  return `-----BEGIN OPENSSH PRIVATE KEY-----
${generateRandomBase64(70)}
${generateRandomBase64(70)}
${generateRandomBase64(70)}
${algorithm === 'ed25519' ? '' : generateRandomBase64(70)}
-----END OPENSSH PRIVATE KEY-----

ssh-${algorithm} ${generateRandomBase64(50)} user@host`;
}

function generateRandomBase64(length: number): string {
  const bytes = new Uint8Array(Math.ceil(length * 3 / 4));
  crypto.getRandomValues(bytes);
  return btoa(String.fromCharCode(...bytes)).substring(0, length);
}

function generateUUID(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

function generateNanoid(length: number): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-';
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map(b => chars[b % chars.length])
    .join('');
}

function generateFingerprint(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join(':');
}
