import { useState } from 'react';
import { Copy, Download, Eye, EyeOff, Check } from 'lucide-react';

interface OutputDisplayProps {
  output: string;
  keyType: string;
}

export default function OutputDisplay({ output, keyType }: OutputDisplayProps) {
  const [copied, setCopied] = useState(false);
  const [hidden, setHidden] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const extension = keyType === 'ssl' || keyType === 'ssh' ? '.pem' : '.txt';
    const blob = new Blob([output], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${keyType}-key-${Date.now()}${extension}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (!output) {
    return (
      <div className="bg-zinc-900 border border-zinc-800 p-8 text-center">
        <div className="text-zinc-600 text-sm">
          Configure your key settings and click "Generate Key" to create a secure key
        </div>
      </div>
    );
  }

  return (
    <div className="bg-zinc-900 border border-zinc-800">
      <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800">
        <div className="text-sm text-zinc-400">Generated Key</div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setHidden(!hidden)}
            className="p-2 hover:bg-zinc-800 transition-colors text-zinc-400 hover:text-zinc-200"
            title={hidden ? 'Show key' : 'Hide key'}
          >
            {hidden ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
          <button
            onClick={handleCopy}
            className="p-2 hover:bg-zinc-800 transition-colors text-zinc-400 hover:text-zinc-200"
            title="Copy to clipboard"
          >
            {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
          </button>
          <button
            onClick={handleDownload}
            className="p-2 hover:bg-zinc-800 transition-colors text-zinc-400 hover:text-zinc-200"
            title="Download key"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>
      <div className="p-4">
        <pre className="text-sm text-zinc-200 whitespace-pre-wrap break-all font-mono">
          {hidden ? '•'.repeat(output.length > 100 ? 100 : output.length) : output}
        </pre>
      </div>
    </div>
  );
}
